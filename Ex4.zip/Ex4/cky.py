import re
import math
import colorsys
import numpy as np
from collections import Counter
import argparse

import os
import time
from data import *
from collections import defaultdict, Counter







    
train_sents = read_conll_ner_file("data/train.conll")
